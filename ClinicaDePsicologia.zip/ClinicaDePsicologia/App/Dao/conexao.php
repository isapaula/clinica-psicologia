<?php
/*
    class Conexao {
    
        public static $instance;
    
        private function __construct() {
            //
        }
    
        public static function getConexao() {
            if (!isset(self::$instance)) {
                self::$instance = new PDO('mysql:host=localhost;dbname=clinica', 'root', '', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
                self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$instance->setAttribute(PDO::ATTR_ORACLE_NULLS, PDO::NULL_EMPTY_STRING);
            }
    
            return self::$instance;
        }
    
    }
    

    try {
        
        
        $sqlPront = "INSERT INTO `prontuario`(`nomePaci`, `tipo`, `email`, `senha`, `Psicologo`, `cpf`, `datanasc`, `sexo`, `tipoTerapia`, `statusPront`, `Faltas`, `Assinatura`) VALUES ('teste', 'testetipo', 'testeemail','testesenha', 0, 'testecpf', 'testedatanasc', 'h', 'testipoTerapia', 'DESATIVADO', 0, 'Sem Assinatura');";

        $conn = Conexao::getConexao();
        $conn->exec($sqlPront);
        
            //$nomeFila =  $fila->getNomeFila();
            //$estaFila =  $fila->getEstaNaFila();

            $sqlfila = "INSERT INTO `fila` (`nomePaciente`, `estaNaFila`, `email`, `cpf`) VALUES ('nomeFila', 'Sim', 'emailfila', null);";
            
            $conn = Conexao::getConexao();
            $conn->exec($sqlfila);

            echo "esta na fila";
            echo "<br><br>";
        echo "cadastrado com sucesso";


    } catch (PDOException $e) {
        echo "erro de conexao: {$e->getMessage()}";
    }

*/