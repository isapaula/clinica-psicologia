<?php
 
    class Sala
    {
        
        
    }
    