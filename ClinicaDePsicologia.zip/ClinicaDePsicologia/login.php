<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/login.css">
    <title>Login</title>
    <link rel="icon" href="img/icons8.png">
</head>
<body>
                    <ul class="ulMenu">
                    <a href=""><img class="logo_img" src="img/icons864.png" alt="Clinica psicologia"></a>
                        <li class="menu"><a  href="#contato">Contato</a></li>
                        <li class="menu"><a  href="#unidades">Unidades</a></li>
                        <li class="menu"><a  href="#servicos">Serviços</a></li>
                        <li class="menu"><a  href="#sobre">Sobre a clínica</a></li>
                        <li class="menu"><a  href="login.php">login/Registro</a></li>
                        <li class="menu"><a  href="#home">Home</a></li>
                    </ul>
        
        <section class="login">
            
                <form class="form" action="funcoes.php" method="post">
                    <div>
                            <div>
                                <a class="Abtn1" href="login.php">Login</a>
                            </div>
                            <div>    
                                <a class="Abtn2" href="Registro.php">Registre</a>
                            </div>
                    </div>
 
                    <p>Sign in with:</p> 

                    <button class="btnicon" type="submit"><i class="fa fa-facebook"></i></button>
                    <button class="btnicon" type="submit"><i class="fa fa-google"></i></button>
                    <button class="btnicon" type="submit"><i class="fa fa-twitter"></i></button>
                    <br>
                    <p>or:</p>
                    <br>
                        <input class="inputLogin" type="email" name="user" id="user" placeholder="  Email or Username"> <br> <br> 
                        <input class="inputLogin" type="password" name="senha" id="senha" placeholder="  Password"><br>
                        <br>
                        <input    type="checkbox" checked="checked"><span>Remember me</span>      <a href="http://" name="" id="aforgot">Forgot password?</a>
                        <br>
                        <br>
                    <button class="button" type="submit" name="login" value="login">Sign in</button>
                    <br>
                    <br>
                    Not a member?<a href="Registro.php">Register</a>
                </form>
         
        </section>
    <script>
        function registro() {
            window.location = 'Registro.php'
        }
    </script>
</body>
</html>
