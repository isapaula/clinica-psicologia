<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinica de Psicologia</title>
    <!-- esse icone fica ao lado do titulo na aba da pagina --><link rel="icon" href="img/icons8.png">
    <!-- google icons-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!-- MATERIALIZE CSS-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <!-- CUSTOM CSS FOI CRIANDO NA MAO NAO FAZ PARTE DO PACOTE MATERIALIZE E NELE VAI ESTAR OS ESTILOS DO SITE FEITOS A MAO -->
    <link rel="stylesheet" href="css/custom.css">

</head>
<body>
    <header>
        <!-- MENU MOBILE-->
        <ul class="sidenav" id="menu-mobile" name="menu-mobile">
            <li><a  class="sidenav-close"  class="black-text" href="#home">Home</a></li>
            <li><a  class="sidenav-close"  class="black-text" href="login.html">login/Registro</a></li>
            <li><a  class="sidenav-close"  class="black-text" href="#sobre">Sobre a clínica</a></li>
            <li><a  class="sidenav-close"  class="black-text" href="#servicos">Serviços</a></li>
            <li><a  class="sidenav-close"  class="black-text" href="#unidades">Unidades</a></li>
            <li><a  class="sidenav-close"  class="black-text" href="#contato">Contato</a></li>
        </ul>
        

        <div class="navbar-fixed">   
            <nav class="navbar z-depth-0">
                <div class="nav-wrapper container">
                    <h1 class="logo_text">
                        Clínica de psicologia
                    </h1>
                    <a href=""><img class="logo_img" src="img/icons864.png" alt="Clinica psicologia"></a>
                    <ul class="right hide-on-med-and-down">
                        <li><a  class="black-text" href="#home">Home</a></li>
                        <li><a  class="black-text" href="login.php">login/Registro</a></li>
                        <li><a  class="black-text" href="#sobre">Sobre a clínica</a></li>
                        <li><a  class="black-text" href="#servicos">Serviços</a></li>
                        <li><a  class="black-text" href="#unidades">Unidades</a></li>
                        <li><a  class="black-text" href="#contato">Contato</a></li>
                    </ul>
                    
                    <a href="#" data-target="menu-mobile" class="sidenav-trigger right"><i class="material-icons">menu</i></a>
            
                </div>
            </nav>
        </div>
    </header>
    <section class="home bloco scrollspy" id="home">
        <div class="row container banner">
            <div class="col s12 center">       
                <h2 class="black-text">Consultas para todos os públicos</h2>
                <p class="black-text light">
                    A clinica realiza atendimento seu espaço para consultas em grupo/familia, individual e casal, assim cada um pode escolher o que ficar melhor  o sigilo entre funcionarios de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aqui.
                </p>
                <div class="row">
                    <a href="#sobre" class="btn btn-large blue-logo"> Sobre nós </a>
                    <a href="#contato" class="btn btn-large white black-text"> Contato </a>
                </div>
            </div>
        </div>
    </section>
    <!-- SOBRE-->
    <section class="sobre bloco scrollspy" id="sobre">
        <div class="row container">
            <div class="col s12 center">
                <h2 class="light titulo">Sobre nós</h2>
            </div>
            <div class="col s12 l6">
                <p class="light paragrafo"> A clinica realiza atendimento seu espaço para consultas em grupo/familia, individual e casal, assim cada um pode escolher o que ficar melhor o sigilo entre funcionarios de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aqui.entre funcionarios de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aquirealiza atendimento seu espaço para consultas em grupo/familia, individual e casal, assim cada um pode escolher o que ficar melhor o sigilo entre funcionarios de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aqui.entre funcionarios de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aqui.
                A clinica realiza atendimento seu espaço para consultas em grupo/familia, individual e casal, assim cada um pode escolher o que ficar melhor o sigilo entre funcionarios de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aqui.entre funcionarios de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aquirealiza atendimento seu espaço para.</p>
            </div>
            <div class="col s12 l6">
                <br>
                <div class="carousel carousel-slider">
                    <a href="#" class="carousel-item"><img src="img/clinica1.jpg" alt="cerebro"></a>
                    <a href="#" class="carousel-item"><img src="img/clinica2.jpg" alt=""></a>
                    <a href="#" class="carousel-item"><img src="img/clinica3.jpg" alt=""></a>
                    


                </div>
            </div>

        </div>
        <div class="row blue-logo missao-visao-valores">
            <div class="container">
                <article class="item col s12 m4 center">
                    <span class="icon"><i class="material-icons medium">
                        transfer_within_a_station </i></span>
                    <h3 class="light">Missao</h3>
                    <p class="light">
                        de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aqui.entre funcionarios de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aqui..
                    </p>
                </article>
                <article class="item col s12 m4 center">
                    <span class="icon"><i class="material-icons  medium">
                        remove_red_eye </i></span>
                    <h3 class="light">Visao</h3>
                    <p class="light">
                        de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aqui.entre funcionarios de prontuarios dos pacientes é mantido, os paciente podem acompanhar suas situaçoes por aqui..
                    </p>
                </article>
                <article class="item col s12 m4 center">
                    <span class="icon"><i class="material-icons medium">
                        grade</i></span>
                    <h3 class="light">Valores</h3>
                    <p class="light">
                        * Itens de lista devem iniciar com letra maiúscula.<br>
                        * Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada. <br>
                        * Uma sentença que antecede uma lista deve ser uma sentença gramaticalmente completa e vir seguida de dois pontos.<br> 
                        * Não recomendável: " The conclusion reached are" (aqui não deve ser colocado ":").<br>
                    </p>
                </article>

            </div> 

        </div>
    </section>
    <!--
        Serviços
    -->
    <section class="servicos bloco scrollspy" id="servicos">
        <div class="row container">
            <div class="col s12 center">
                <h2 class="light titulo">Serviços</h2>
                <p class="light paragrafo">Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada..</p>

            </div>
        </div>
        <div class="row container">
            <!-- CONSULTAS -->
            <article class="col s12 m6 l3">
                <div class="card">
                    <div class="card-image">
                        <img src="img/brain.jpg" alt="brain" class="material-boxed">
                            <a href="#consultas-modal" class="btn btn-floating  halfway-fab blue-logo modal-trigger">
                            <i class="material-icons">more_horiz</i>
                        </a>
                    </div>
                    <div class="card-content">
                        <h3 class="card-title">Consultas</h3>
                        <p class="light">Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada Itens de lista devem fechar com pont

                        </p>
                    </div>
                </div>     
            </article>
             <!-- MODAL CONSULTAS -->
             <div class="modal" id="consultas-modal">
                <div class="modal-content">
                    <h5 class="light"> Como sao as consultas?</h5>
                    <p>
                        fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada Itens de lista devem fechar com pon
                    </p>
                    <h5 class="light"> Como sao realizadas?</h5>
                    <ul class="collection">
                        <li class="collection-item">
                            Paciente faz o cadastro;
                        </li>
                        <li class="collection-item">
                            Paciente vai para fila de agendadmento;
                        </li>
                        <li class="collection-item">
                            Aguarda triagem;
                        </li>
                        <li class="collection-item">
                            Após triagem decide se se o tramento vai continuar ou não</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <a class="btn blue-logo modal-action modal-close">Sair</a>
                </div>
            </div>
            <!-- PRONTUÁRIOS -->
            <article class="col s12 m6 l3">
                <div class="card">
                    <div class="card-image">
                        <img src="img/brain.jpg" alt="brain" class="material-boxed">
                            <a href="#prontuarios-modal" class="btn btn-floating  halfway-fab blue-logo modal-trigger">
                            <i class="material-icons">more_horiz</i>
                        </a>
                    </div>
                    <div class="card-content">
                        <h3 class="card-title">Prontuários</h3>
                        <p class="light">Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada Itens de lista devem fechar com pont
                        </p>

                    </div>
                </div>     
            </article>
            <!-- PRONTUARIOS MODAL-->
            <div class="modal" id="prontuarios-modal">
                <div class="modal-content">
                    <h5>
                        Como funciona os prontuários?
                    </h5>
                    <p>
                        Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada Itens de lista devem fechar com pont
                    </p>
                    <h5>
                       O que voce pode acessar? 
                    </h5>
                    <ul class="collection">
                        <li class="collection-item">
                            Suas consultas;
                        </li>
                        <li class="collection-item">
                            Seu progresso;
                        </li>
                        <li class="collection-item">
                            Eventos;
                        </li>
                        
                    </ul>
                </div>
                <div class="modal-footer">
                    <a class="btn blue-logo modal-action modal-close">Sair</a>
                </div>

            </div>
            <!-- SESSÔES -->
            <article class="col s12 m6 l3">
                <div class="card">
                    <div class="card-image">
                        <img src="img/brain.jpg" alt="brain" class="material-boxed">
                            <a href="#sessoes-modal" class="btn btn-floating  halfway-fab blue-logo modal-trigger">
                            <i class="material-icons">more_horiz</i>
                        </a>
                    </div>
                    <div class="card-content">
                        <h3 class="card-title">Sessoes</h3>
                        <p class="light">Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada Itens de lista devem fechar com pont

                        </p>
                    </div>
                </div>     
            </article>
            <!-- SESSOES MODAL-->
            <div class="modal" id="sessoes-modal">
                <div class="modal-content">
                    <h5>
                        Como funciona os prontuários?
                    </h5>
                    <p>
                        Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada Itens de lista devem fechar com pont
                    </p>
                    <h5>
                       O que voce pode acessar? 
                    </h5>
                    <ul class="collection">
                        <li class="collection-item">
                            Suas consultas;
                        </li>
                        <li class="collection-item">
                            Seu progresso;
                        </li>
                        <li class="collection-item">
                            Eventos;
                        </li>
                        
                    </ul>
                </div>
                <div class="modal-footer">
                    <a class="btn blue-logo modal-action modal-close">Sair</a>
                </div>
            </div>
            <!-- MAIS INFORMACOES -->
            <article class="col s12 m6 l3">
                <div class="card">
                    <div class="card-image">
                        <img src="img/brain.jpg" alt="brain" class="material-boxed">
                            <a href="#maisinfo" class="btn btn-floating  halfway-fab blue-logo modal-trigger">
                            <i class="material-icons">more_horiz</i>
                        </a>
                    </div>
                    <div class="card-content">
                        <h3 class="card-title">Mais informaçoes</h3>
                        <p class="light">Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada Itens de lista devem fechar com pont

                        </p>
                    </div>
                </div>     
            </article>
           <!-- BOTAO QUADRO DE HORARIOS-->
            <div class="row center btn-horario">
                <a href="#horario-modal"  class="btn btn-large blue-logo modal-trigger"><i class="material-icons left">timer</i> Quadro de horários</a>
            </div>
            <!-- MODAL QUADRO DE HORARIOS-->
            <div class="modal" id="horario-modal">
                <div class="modal-content">
                    <h5>
                        Quadro de Horarios
                    </h5>
                    <ul class="tabs">
                        <li class="tab col s3"><a href="#tabela-consultas">Consultas</a>
                        </li>
                        <li class="tab col s3">
                            <a href="#tabela-sessoes">Sessoes</a>
                        </li>
                        <li class="tab col s3">
                            <a href="#tabela-filas">Filas</a>
                        </li>
                        <li class="tab col s3">
                            <a href="#tabela-salas">Salas</a>
                        </li>
                    </ul>
                    <table class="striped responsive-table" id="tabela-consultas">
                        <thead>
                            <tr>
                                <th></th>
                                <th> Segunda </th>
                                <th> Terça   </th>
                                <th> Quarta  </th>
                                <th> Quinta  </th>
                                <th> Sexta   </th>
                                <th> Sábado  </th>
                                <th> Domingo </th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php 
                                


                            ?>
                        </tbody>
                    </table>
                    <table class="striped responsive-table" id="tabela-sessoes">
                        <thead>
                            <tr>
                                <th></th>
                                <th> Segunda </th>
                                <th> Terça   </th>
                                <th> Quarta  </th>
                                <th> Quinta  </th>
                                <th> Sexta   </th>
                                <th> Sábado  </th>
                                <th> Domingo </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                
                                <td>Sessoes</td>
                                <td>grupo</td>
                                <td>individual</td>
                                <td>casal</td>
                                <td>individual</td>
                                <td>grupo</td>
                                <td>casal</td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                
                                <td>Sessoes</td>
                                <td>grupo</td>
                                <td></td>
                                <td>individual</td>
                                <td></td>
                                <td>grupo</td>
                                <td></td>
                                <td>casal</td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>

                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>

    </section>
    <!-- UNIDADES -->
    <section class="unidades bloco scrollspy" id="unidades">
        <div class="row container">
            <div class="col s12 center">
                <h2 class="light titulo white-text">Unidades</h2>
                <p class="light paragrafo white-text">Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada Itens de lista devem fechar com ponto se formarem sentenças completas. Caso contrário, nenhuma pontuação deve ser usada..</p>

            </div>
        </div>
        <div class="row container">
            <article class="col s12 l6">
                <div class="card horizontal">
                    <div class="card-image">
                        <img src="img/clinica2.jpg" alt="plano">
                    </div>
                    <div class="card-stacked">
                        <div class="card-content">
                            <h3 class="card-title light">Sao Paulo</h3>
                            
                                <i class="material-icons left">phone</i>123 456 789 <br>
                                <i class="material-icons left">email</i>saopaulo@hotmail.com<br>
                                <i class="material-icons left">location_on</i>av dos contos 025
                            
                        </div>
                    </div>
                </div>
            </article>
            <article class="col s12 l6">
                <div class="card horizontal">
                    <div class="card-image">
                        <img src="img/clinica1.jpg" alt="plano">
                    </div>
                    <div class="card-stacked">
                        <div class="card-content">
                            <h3 class="card-title light">Plano Piloto</h3>
                            
                                <i class="material-icons left">phone</i>123 456 789 <br>
                                <i class="material-icons left">email</i>asasula@hotmail.com<br>
                                <i class="material-icons left">location_on</i>Asa sul w3 958
                            
                        </div>
                    </div>
                </div>
            </article>
        </div>

    </section>
    <!--CONTATO-->
    <section class="contato bloco scrollspy" id="contato">
        <div class="row container">
            <div class="col s12 center">
                <h2 class="titulo black-text">Contato</h2>
            </div>
            <div class="col s12 m6 l4 hide-on-med-only">
                <div  class="mapa transparente">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3839.081702017793!2d-47.899518199999996!3d-15.7996454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x935a3aebad72a75b%3A0xca61f12d41f213ab!2sCentro%20Universit%C3%A1rio%20do%20Distrito%20Federal%20-%20UDF!5e0!3m2!1spt-BR!2sbr!4v1603298157876!5m2!1spt-BR!2sbr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe> 
                </div>
            </div>
            <div class="col s12 m6 l4">
                <div class="informacoes white-text">
                    <h4>
                        Redes Sociais
                    </h4>
                    <p class="light">
                        fiqu por dentro de outras informaçoes a respeito da clinica.
                    </p>
                    <a href="#" class="btn-floating blue-logo"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="btn-floating blue-logo"><i class="fa fa-google"></i></a>
                    <a href="#" class="btn-floating blue-logo"><i class="fa fa-twitter"></i></a>
                    
                    <h4>Endereço</h4>
                    <p class="light">
                        Asa sul 956
                    </p>
                    <h4>Contatos</h4>
                    <p class="light">
                        (61) 1234-6547
                    </p>
                    <p class="light">
                        (61)  3698-8521
                    </p>
                </div>
            </div>
            <div class="col s12 m6 l4">
                <div class="formulario white black-text">
                    <h4>Fale conosco</h4>
                    <p>
                        Duvidas, criticas ou sugestoes ?Entre em contato conosco, seu feedback é muito importante.
                    </p>
                    <form action="" method="POST">
                        <div class="input-field">
                            <input type="text" name="nome" id="nome">
                            <label for="Name">Seu nome</label>
                        </div>
                        <div class="input-field">
                            <input type="email" name="email" id="email">
                            <label for="email">Seu email</label>
                        </div>
                        <div class="input-field">
                            <input type="text" name="assunto" id="assunto">
                            <label for="assunto">Assunto</label>
                        </div>
                        <div class="input-field">
                            <textarea id="message" class="materialize-textarea"></textarea>
                            <label for="message">Mensagem</label>
                        </div>
                        <button type="submit" class="btn btn-logo"> Enviar </button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <div class="depoimentos blue-logo">
        <div class="row container">
            <div class="col s12 center">
                <h2 class="titulo black-text light">
                    Depoimentos
                </h2>
            </div>
            <div class="col s12 m4 center">
                <img src="img/person_1.jpg" class="circle responsive-img " alt="person1" >
                <p class="light white-text">
                    Sou etudante do curso de arquitetura e estou gostando muito das consultas em grupo da clinica psicologia aqui. 
                </p>
                <h4 class="light  white-text">
                    Felipe Sousa
                </h4>
                <p class="white-text">
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>

                </p>
            </div>
            <div class="col s12 m4 center">
                <img src="img/person_4.jpg" class="circle responsive-img " alt="person1" >
                <p class="light white-text">
                    Sou um dos alunos de psicologia e para mim a clinica ja uma forma de ter um vislumbre da vida em consultorio alem de dar uma experiencia. 
                </p>
                <h4 class="light  white-text">
                    Paula Santos
                </h4>
                <p class="white-text">
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>

                </p>
            </div>
            <div class="col s12 m4 center">
                <img src="img/person_2.jpg" class="circle responsive-img " alt="person1" >
                <p class="light white-text">
                    Achei muito interessante essa ideia da clinica pois treina os alunos e ajuda outras pessoas. 
                </p>
                <h4 class="light  white-text">
                    Suelem Rodrigues
                </h4>
                <p class="white-text">
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>
                    <i class="material-icons">star</i>

                </p>
            </div>


        </div>
    </div>

    <!--
        RODA PE    -->
        <footer class="rodape">
            <div class="row container center">
                <img src="img/icons864.png" class="logo_img" alt="">
                <p>
                    @A clinica esta disponivel para consultas todos os dias da semana 
                </p>
            </div>
        </footer>

    <!-- Jquery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script>
       $(document).ready(function(){
         $('.sidenav').sidenav();
         $('.scrollspy').scrollSpy({
             scrollOffset: 0
         });
         $(".carousel.carousel-slider").carousel({
             fullWidth:true,
             indicators: true
         });
         //modal
         $(".modal").modal();
         // TABS
         $("ul.tabs").tabs();
        // auto play
        function autoplay(){
            $(".carousel").carousel("next");
            setTimeout(autoplay,4500);
        } 
        autoplay();
    });
    // adicionando nav color
    $(window).on("scroll",function(){
        if ($(window).scrollTop() > 100) {
            $(".navbar").addClass("nav-color");
        }else{
            $(".navbar").removeClass("nav-color");
        }

    });  
    </script>

    <!--MATERIALIZA JS-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

</body>
</html>