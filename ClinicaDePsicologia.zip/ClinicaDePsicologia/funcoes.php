<?php 

    require_once('App/contoller/controller.php');
    require_once('App/fila.php');
    require_once('App/prontuario.php');
    

    $prontuario = new Prontuario;
    $controller = new Controller;
    $fila       = new Fila;
    $logar      = new Login;

    $dados = filter_input_array(INPUT_POST);

    
    if(isset($_POST['cadastrar'])){

        $nome  = isset($_POST['nome']) ? filter_var($_POST['nome'], FILTER_SANITIZE_SPECIAL_CHARS) : "digite este campo";
        $tipo  = "Pendente";
        $email = isset($_POST['email']) ?  filter_var($_POST['email'],FILTER_SANITIZE_EMAIL)  : "digite este campo";
        $senha = isset($_POST['senha']) ? filter_var($_POST['senha'],FILTER_SANITIZE_EMAIL)  : "digite este campo";
        $psicologo = 0;
        $cpf   = isset($_POST['cpf'])   ? filter_var($_POST['cpf'], FILTER_SANITIZE_SPECIAL_CHARS)    : "digite este campo";
        $datanasc = isset($_POST['datanasc']) ? $_POST['datanasc'] : "digite este campo";
        $sexo = isset($_POST['sexo']) ? $_POST['sexo'] : "digite este campo";
        $tipoTerapia = isset($_POST['tipoTerapia']) ? $_POST['tipoTerapia'] : "digite este campo";

        $senhacrip = password_hash($senha, PASSWORD_DEFAULT);
        

        $prontuario->setNomePaci($nome);
        $prontuario->setTipo($tipo);
        $prontuario->setEmail($email);
        $prontuario->setSenha($senhacrip);
        $prontuario->setCpf($cpf);
        $prontuario->setDatanasci($datanasc);
        $prontuario->setSexo($sexo);
        $prontuario->settipoTerapia($tipoTerapia);

        $fila->setNomeFila($nome);
        $fila->setEstaNaFila('Sim');
        $fila->setEmail($email);

        $controller->create($fila, $prontuario);

    }

    if (isset($_POST['login'])) {

        $user = isset($_POST['user']) ? $_POST['user']  : "login incorreto ou vazio"; 
    
        $senha = isset($_POST['senha']) ? $_POST['senha']  : "senha incorreto ou vazio";

        $logar->setUser($user);
        $logar->setSenha($senha);

        $controller->login($logar->getUser(), $logar->getSenha());
        
    }

    if (isset($_POST['editar'])) {
        
    }
    if (isset($_POST['del'])) {
        
    }
    