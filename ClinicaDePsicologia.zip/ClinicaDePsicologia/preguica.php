<?php

$nome = 'pedro';
$$nome = 'maria';

echo $$nome;


/*
    $horarios = [];
   $array = array(
       "2" => 'segunda',
       "3" => 'Terça',
       "4" => 'Quarta',
       "5" => 'Sexta',
        
       for ($i=8; $i <= 17 ; $i++) { 
            
        if ($i < 10) {
            $dias[$i] =  "0{$i}:00 as 0{$i}:50";
            
        }else {
            $dias[$i] =  "{$i}:00 as {$i}:50"; 
        }
    }
    );


  

echo "<pre>";
print_r($dias);
echo "</pre>";