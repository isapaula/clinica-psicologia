<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/bootstrap-grid.min.css">
    <link rel="stylesheet" href="css/registro.css">
    <title>Registre se</title>
    <link rel="icon" href="img/icons8.png">
</head>
<body>
                    
                    <ul>
                    <a href=""><img class="logo_img" src="img/icons864.png" alt="Clinica psicologia"></a>
                        <li><a  href="#contato">Contato</a></li>
                        <li><a  href="#unidades">Unidades</a></li>
                        <li><a  href="#servicos">Serviços</a></li>
                        <li><a  href="#sobre">Sobre a clínica</a></li>
                        <li><a  href="login.php">login/Registro</a></li>
                        <li><a  href="#home">Home</a></li>
                    </ul>
        
        <section class="login">
            
                <form class="form" action="funcoes.php" method="post">
                    <div>
                            <div>
                                <a class="Abtn1" href="login.php">Login</a>
                            </div>
                            <div>    
                                <a class="Abtn2" href="registro.php">Registre-se</a>
                            </div>
                    </div>
                   
                    <p>Login com:</p> 

                    <button class="btnicon" type="submit"><i class="fa fa-facebook"></i></button>
                    <button class="btnicon" type="submit"><i class="fa fa-google"></i></button>
                    <button class="btnicon" type="submit"><i class="fa fa-twitter"></i></button>
                    
                    <p>ou:</p>
                    
                        <input class="inputLogin" type="text"     name="nome" id="nome" placeholder="  Nome Completo"> <br> <br> 
                        <input class="inputLogin" type="email"    name="email" id="email" placeholder="  Email"> <br> <br>
                        <input class="inputLogin" type="password" name="senha" id="senha" placeholder="  Senha"><br><br> 
                        <input class="inputLogin" type="text" name="cpf" id="cpf" placeholder="  CPF"> <br> <br>
                        <input class="inputLogin" type="date" name="datanasc" id="datanasc" placeholder="  Data de Nascimento"> <br> <br>
                        <div>
                            <div>
                                <select class="inputLogin" name="sexo" id="sexo">
                                    <option selected>Sexo</option>
                                    <option value="F">Feminino</option>
                                    <option value="M">Masculino</option>
                                </select><br> <br>
                            </div>
                            <div>
                                <select class="inputLogin" name="tipoTerapia" id="tipoTerapia">
                                    <option value="">Selecione...</option>
                                    <option value="Individual">Individual</option>
                                    <option value="Casal">Casal</option>
                                    <option value="Familia">Família</option>
                                </select><br> <br>
                            </div>
                        </div>
                        
                    <button class="button" type="submit" name="cadastrar" value="cadastrar">Cadastrar</button>
                    <br>
                    <br>
                </form>
           
        </section>
    
</body>
</html>
