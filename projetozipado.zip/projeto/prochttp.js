const http =  require('http');

const srv = http.createServer((req,res)) =>{
    console.log('METHOD:')
}